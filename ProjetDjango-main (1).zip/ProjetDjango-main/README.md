La version final du projet : https://github.com/SalaheddineS/ProjetDjango/commit/3a339642c6857c4726326fde0228786eea52e367
